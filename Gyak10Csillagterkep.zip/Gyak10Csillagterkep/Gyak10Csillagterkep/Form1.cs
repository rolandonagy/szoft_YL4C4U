using Gyak10Csillagterkep.Models;

namespace Gyak10Csillagterkep
{
    public partial class Form1 : Form
    {
        HajosContext context = new HajosContext();
        public Form1()
        {
            InitializeComponent();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            var stars = (from s in context.StarData select new { s.Hip, s.X, s.Y, s.Magnitude }).ToList();

            Graphics g = this.CreateGraphics();

            g.Clear(Color.DarkCyan);
            Color c = Color.Gold;

            Pen toll = new Pen(c, 1);
            Brush brush = new SolidBrush(c);

            double nagyitas = 400;

            float cx = ClientRectangle.Width / 2;
            float cy = ClientRectangle.Height / 2;

            foreach (var star in stars)
            {
                if (star.Magnitude > 6) continue;
                if (Math.Sqrt(Math.Pow(star.X, 2) + Math.Pow(star.Y, 2)) > 1) continue;
                    float x1 = (float)(nagyitas * star.X);
                    float y1 = (float)(nagyitas * star.Y);

                    double size = 20 * Math.Pow(10, (star.Magnitude) / -2.5);

                    if (size < 2) size = 1;
                    g.FillEllipse(brush, x1 + cx, y1 + cy, (float)size, (float)size);
                
            }
            var lines = context.ConstellationLines.ToList();

            foreach (var line in lines)
            {
                var star1 = (from s in stars where s.Hip == line.Star1 select s).FirstOrDefault();
                var star2 = (from s in stars where s.Hip == line.Star2 select s).FirstOrDefault();

                if (star1 == null || star2 == null) continue;

                float x1 = (float)(nagyitas * star1.X);
                float y1 = (float)(nagyitas * star1.Y);
                float x2 = (float)(nagyitas * star2.X);
                float y2 = (float)(nagyitas * star2.Y);

                g.DrawLine(toll, x1 + cx, y1 + cy, x2 + cx, y2 + cy);
            }
        }
    }
}