﻿using System;
using System.Collections.Generic;

namespace Gyak10Csillagterkep.Models;

public partial class ConstellationLine
{
    public int Star1 { get; set; }

    public int Star2 { get; set; }
}
