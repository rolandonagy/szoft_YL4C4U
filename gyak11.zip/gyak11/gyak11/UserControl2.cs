﻿using gyak11.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace gyak11
{
    public partial class UserControl2 : UserControl
    {
        Models.StudiesContext context = new Models.StudiesContext();
        public UserControl2()
        {
            InitializeComponent();
            Adatbetoltes();
            listBox1.DisplayMember = "Name";
        }
        private void Adatbetoltes()
        {
            var ilist = from i in context.Courses
                        where i.Name.Contains(textBox1.Text)
                        select i;
            listBox1.DataSource = ilist.ToList();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            Adatbetoltes();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBox1.SelectedItem == null) return;
            Course course = listBox1.SelectedItem as Course;

            var lessons = from l in context.Lessons
                          where l.CourseFk == course.CourseSk
                          select new
                          {
                              Kurzus = l.CourseFkNavigation.Name,
                              Nap = l.DayFkNavigation.Name,
                              Sáv = l.TimeFkNavigation.Name
                          };
            dataGridView1.DataSource = lessons.ToList();
        }
    }
}
